muban.短视2.二级.img = '.detail-pic&&img&&data-src';
var rule = {
    title: 'NyaFun',
    模板:'短视2',
    host: 'https://www.nyafun.net',
    homeUrl:'/map.html',
	url: '/index.php/api/vod#type=fyclass&page=fypage',
    class_name:'番剧&剧场',
    class_url:'2&1',
    detailUrl:'/bangumi/fyid.html',
    推荐:'.border-box .public-list-box;a&&title;.lazy&&data-src;.public-list-prb&&Text;a&&href',
    double: false, // 推荐内容是否双层定位
}