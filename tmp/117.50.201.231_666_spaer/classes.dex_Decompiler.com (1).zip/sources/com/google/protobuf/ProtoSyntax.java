package com.google.protobuf;

/* JADX INFO: loaded from: /tmp/decompiler/61445fe823f54055bb8486d86e79a950/classes.dex */
public enum ProtoSyntax {
    PROTO2,
    PROTO3,
    EDITIONS
}
