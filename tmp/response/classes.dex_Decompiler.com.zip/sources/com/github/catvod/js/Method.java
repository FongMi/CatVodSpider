package com.github.catvod.js;

import com.github.catvod.spider.merge.p.C0219l;
import com.whl.quickjs.wrapper.JSMethod;
import com.whl.quickjs.wrapper.QuickJSContext;

/* JADX INFO: loaded from: /tmp/decompiler/446907477a41490d9e71cfdd71d695e7/classes.dex */
public class Method {
    private final QuickJSContext ctx;

    public Method(QuickJSContext quickJSContext) {
        this.ctx = quickJSContext;
    }

    @JSMethod
    public void showToast(String str) {
        C0219l.b(str);
    }
}
