package com.github.catvod.parser;

import com.github.catvod.crawler.SpiderDebug;
import com.github.catvod.spider.merge.a.C0098a;
import com.github.catvod.spider.merge.p.C0214g;
import com.github.catvod.spider.merge.q.f;
import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONObject;

/* JADX INFO: loaded from: /tmp/decompiler/446907477a41490d9e71cfdd71d695e7/classes.dex */
public class JsonSequence {
    public static JSONObject parse(LinkedHashMap<String, String> linkedHashMap, String str) {
        try {
            if (linkedHashMap.size() > 0) {
                for (String str2 : linkedHashMap.keySet()) {
                    try {
                        HashMap<String, String> reqHeader = JsonBasic.getReqHeader(linkedHashMap.get(str2));
                        String str3 = reqHeader.get(C0098a.a(new byte[]{124, 125, -78}, new byte[]{9, 15, -34, -25, 114, -124, 76, -41}));
                        reqHeader.remove(C0098a.a(new byte[]{66, -12, -110}, new byte[]{55, -122, -2, -18, -87, -19, 94, 102}));
                        SpiderDebug.log(str3 + str);
                        JSONObject jSONObjectC = C0214g.c(str, f.f(str3 + str, reqHeader));
                        if (jSONObjectC != null) {
                            jSONObjectC.put(C0098a.a(new byte[]{-11, 63, -81, -120, 96, 51}, new byte[]{-97, 71, -23, -6, 15, 94, 116, -1}), str2);
                            return jSONObjectC;
                        }
                    } catch (Throwable th) {
                        SpiderDebug.log(th);
                    }
                }
            }
        } catch (Throwable th2) {
            SpiderDebug.log(th2);
        }
        return new JSONObject();
    }
}
