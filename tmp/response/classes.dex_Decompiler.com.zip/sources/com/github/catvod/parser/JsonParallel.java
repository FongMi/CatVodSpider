package com.github.catvod.parser;

import com.github.catvod.crawler.SpiderDebug;
import com.github.catvod.spider.merge.a.C0098a;
import com.github.catvod.spider.merge.p.C0214g;
import com.github.catvod.spider.merge.q.f;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.json.JSONObject;

/* JADX INFO: loaded from: /tmp/decompiler/446907477a41490d9e71cfdd71d695e7/classes.dex */
public class JsonParallel {
    private static final String a = C0098a.a(new byte[]{-83, -57, -39, 71, -89, -8, -115, 11, -68, -22, -64, 81}, new byte[]{-35, -104, -77, 52, -56, -106, -46, 123});

    public static JSONObject parse(LinkedHashMap<String, String> linkedHashMap, final String str) {
        JSONObject jSONObject;
        Throwable th;
        try {
            if (linkedHashMap.size() > 0) {
                ExecutorService executorServiceNewFixedThreadPool = Executors.newFixedThreadPool(3);
                ExecutorCompletionService executorCompletionService = new ExecutorCompletionService(executorServiceNewFixedThreadPool);
                ArrayList arrayList = new ArrayList();
                for (final String str2 : linkedHashMap.keySet()) {
                    final String str3 = linkedHashMap.get(str2);
                    arrayList.add(executorCompletionService.submit(new Callable<JSONObject>() { // from class: com.github.catvod.parser.JsonParallel.1
                        @Override // java.util.concurrent.Callable
                        public JSONObject call() {
                            try {
                                HashMap<String, String> reqHeader = JsonBasic.getReqHeader(str3);
                                String str4 = reqHeader.get(C0098a.a(new byte[]{-97, 65, 28}, new byte[]{-22, 51, 112, 39, 28, -62, -127, -34}));
                                reqHeader.remove(C0098a.a(new byte[]{42, -3, -51}, new byte[]{95, -113, -95, -69, 50, -38, -98, 65}));
                                SpiderDebug.log(str4 + str);
                                JSONObject jSONObjectC = C0214g.c(str, f.g(f.b(), str4 + str, C0098a.a(new byte[]{3, -72, -109, -30, 8, 75, 104, -65, 18, -107, -118, -12}, new byte[]{115, -25, -7, -111, 103, 37, 55, -49}), reqHeader, null));
                                jSONObjectC.put(C0098a.a(new byte[]{-71, -80, 59, -2, -71, 47}, new byte[]{-45, -56, 125, -116, -42, 66, -22, -125}), str2);
                                SpiderDebug.log(jSONObjectC.toString());
                                return jSONObjectC;
                            } catch (Throwable th2) {
                                SpiderDebug.log(th2);
                                return null;
                            }
                        }
                    }));
                }
                JSONObject jSONObject2 = null;
                int i = 0;
                while (true) {
                    if (i < arrayList.size()) {
                        try {
                            jSONObject = (JSONObject) executorCompletionService.take().get();
                        } catch (Throwable th2) {
                            jSONObject = jSONObject2;
                            th = th2;
                        }
                        if (jSONObject != null) {
                            try {
                                f.a(a);
                                for (int i2 = 0; i2 < arrayList.size(); i2++) {
                                    try {
                                        ((Future) arrayList.get(i2)).cancel(true);
                                    } catch (Throwable th3) {
                                        SpiderDebug.log(th3);
                                    }
                                }
                                arrayList.clear();
                                jSONObject2 = jSONObject;
                                break;
                            } catch (Throwable th4) {
                                th = th4;
                                SpiderDebug.log(th);
                                jSONObject2 = jSONObject;
                                i++;
                            }
                        } else {
                            continue;
                            jSONObject2 = jSONObject;
                            i++;
                        }
                    }
                }
                try {
                    executorServiceNewFixedThreadPool.shutdownNow();
                } catch (Throwable th5) {
                    SpiderDebug.log(th5);
                }
                if (jSONObject2 != null) {
                    return jSONObject2;
                }
            }
        } catch (Throwable th6) {
            SpiderDebug.log(th6);
        }
        return new JSONObject();
    }
}
