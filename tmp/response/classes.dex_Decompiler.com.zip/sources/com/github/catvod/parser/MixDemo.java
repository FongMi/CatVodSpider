package com.github.catvod.parser;

import android.util.Base64;
import com.github.catvod.spider.merge.a.C0098a;
import com.github.catvod.spider.merge.oZP;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: /tmp/decompiler/446907477a41490d9e71cfdd71d695e7/classes.dex */
public class MixDemo {
    public static HashMap<String, ArrayList<String>> a = new HashMap<>();
    static HashMap<String, ArrayList<String>> b = null;

    private static String a(String str, String str2) {
        int iIndexOf;
        if (str2.trim().length() <= 0 || (iIndexOf = str.indexOf(C0098a.a(new byte[]{19}, new byte[]{44, 9, -101, 77, -108, 96, -49, 26}))) <= 0) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        int i = iIndexOf + 1;
        sb.append(str.substring(0, i));
        sb.append(C0098a.a(new byte[]{-85, -59, 80, 23, -17, 19, 55, -51}, new byte[]{-56, -92, 36, 72, -118, 107, 67, -16}));
        sb.append(Base64.encodeToString(str2.getBytes(), 10));
        sb.append(C0098a.a(new byte[]{45}, new byte[]{11, 105, -77, 38, -62, 127, 20, -7}));
        sb.append(str.substring(i));
        return sb.toString();
    }

    public static Object[] loadHtml(String str, String str2) {
        try {
            String str3 = new String(Base64.decode(str2, 10), StandardCharsets.UTF_8);
            String strD = oZP.d("7F5356250336011607244C3D01021B7F66691D1B1A2D525F49071220086B7F530328183910519FE6CFB3EBFF4B6E183C0103127F6669180A03204C3D011B076C09240006017C4E161A0103240221583B0E310977550C182F18301B1B4A6318300D1B58291838195457220434071C1235512001095A794E755A517D7D0130010E5729182105421230193C0352551941003442342E0125141B1E230030574F142E02211001037C4E1C3052322C1939141B12082964454D576E525F490212350D751B0E1A245177070A19250927101D55610F3A1B1B122F186857181223073C01131E2441361A02073D0530581C0320023157517D7D0130010E572F0D38105255370530021F18331877550C182F18301B1B4A631B3C111B1F7C08300306142441221C0B03294E6B7F535829093411517D7D0E3A1116494B5026161D1E31186B7F1916334C34050636331E340C522C62062D064C2A7A6623141D57341E39251C4A634F2007035463575F030E05610533070E1A24242118034A634E6E7F0918334423141D572851654E064B201C3C341D0520157B190A1926183D4E065C6A452E7F1916334C0027234A201C3C341D0520150E1C325C341E39251C4C4B0533070E1A24242118034A280A271402120918381944557D0533070E1A244C2614011323032D4848162D003A024204221E3C051B04610D391900006C1F34180A5A2E1E3C120619610D391900006C0A3A070204664C33070E1A240E3A070B123351724548572000391A1811340039060C0524093B484803331930524F00240E3E1C1B162D003A0209022D0026161D12240268521B053409725502183B0D39190000271939191C143309301B5250351E20104857321E36484D5C143E195E4D497D433C131D162C096B57547D3C66311A0C022C093B01410033052110471E271E34180A3F3501395C547D7D4326161D1E31186B7F53582303310C517D7D433D01021B7F");
            StringBuilder sb = new StringBuilder();
            byte b2 = 16;
            byte b3 = 50;
            if (a.containsKey(str)) {
                ArrayList<String> arrayList = a.get(str);
                int i = 0;
                while (i < arrayList.size()) {
                    sb.append(C0098a.a(new byte[]{b3}, new byte[]{b2, 105, -82, 68, -121, 5, 118, 0}));
                    sb.append(arrayList.get(i));
                    sb.append(C0098a.a(new byte[]{33}, new byte[]{3, -67, 41, -112, 4, 25, 61, 28}));
                    if (i < arrayList.size() - 1) {
                        sb.append(C0098a.a(new byte[]{89}, new byte[]{117, -121, -19, 33, 88, 16, -58, -8}));
                    }
                    i++;
                    b2 = 16;
                    b3 = 50;
                }
            }
            return new Object[]{200, C0098a.a(new byte[]{-121, -67, -121, 28, -80, -97, 0, -104, -97, -29, -33, 11, -9, -106, 6, -122, -106, -84, -62, 74, -54, -93, 50, -40, -53, -6}, new byte[]{-13, -40, -1, 104, -97, -9, 116, -11}), new ByteArrayInputStream(strD.replace(C0098a.a(new byte[]{-48, 93, -80, 56, 37}, new byte[]{-13, 40, -62, 84, 6, 80, 0, 15}), str3).replace(C0098a.a(new byte[]{49, 63, 74, -111, -27}, new byte[]{18, 85, 50, -30, -58, 1, 28, 104}), sb.toString()).getBytes(StandardCharsets.UTF_8))};
        } catch (Throwable th) {
            th.printStackTrace();
            return null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:61:0x00d6 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static org.json.JSONObject parse(java.util.LinkedHashMap<java.lang.String, java.util.HashMap<java.lang.String, java.lang.String>> r29, java.lang.String r30, java.lang.String r31, java.lang.String r32) {
        /*
            Method dump skipped, instruction units count: 1690
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.github.catvod.parser.MixDemo.parse(java.util.LinkedHashMap, java.lang.String, java.lang.String, java.lang.String):org.json.JSONObject");
    }
}
