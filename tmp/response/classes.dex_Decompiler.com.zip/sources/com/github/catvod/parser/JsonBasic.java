package com.github.catvod.parser;

import android.util.Base64;
import com.github.catvod.crawler.SpiderDebug;
import com.github.catvod.spider.merge.a.C0098a;
import com.github.catvod.spider.merge.p.C0214g;
import com.github.catvod.spider.merge.q.f;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import org.json.JSONObject;

/* JADX INFO: loaded from: /tmp/decompiler/446907477a41490d9e71cfdd71d695e7/classes.dex */
public class JsonBasic {
    public static HashMap<String, String> getReqHeader(String str) {
        HashMap<String, String> map = new HashMap<>();
        map.put(C0098a.a(new byte[]{8, -85, 123}, new byte[]{125, -39, 23, -70, -73, 78, -80, -84}), str);
        if (str.contains(C0098a.a(new byte[]{65, 12, 5, 87, -27, -111, -28}, new byte[]{34, 109, 113, 8, -128, -23, -112, -90}))) {
            try {
                int iIndexOf = str.indexOf(C0098a.a(new byte[]{29, -110, -97, -77, -10, -54, 55, -95}, new byte[]{126, -13, -21, -20, -109, -78, 67, -100}));
                int iIndexOf2 = str.indexOf(C0098a.a(new byte[]{17}, new byte[]{55, 122, 121, -43, -40, -114, -81, -57}), iIndexOf);
                String str2 = new String(Base64.decode(str.substring(iIndexOf + 8, iIndexOf2), 10));
                String str3 = str.substring(0, iIndexOf) + str.substring(iIndexOf2 + 1);
                JSONObject jSONObject = new JSONObject(str2);
                if (jSONObject.has(C0098a.a(new byte[]{-28, 18, 70, 25, -47, 100}, new byte[]{-116, 119, 39, 125, -76, 22, -18, 45}))) {
                    JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject(C0098a.a(new byte[]{-34, 57, -114, 100, -2, 60}, new byte[]{-74, 92, -17, 0, -101, 78, 83, 55}));
                    Iterator<String> itKeys = jSONObjectOptJSONObject.keys();
                    while (itKeys.hasNext()) {
                        String next = itKeys.next();
                        map.put(next, jSONObjectOptJSONObject.optString(next, ""));
                    }
                }
                map.put(C0098a.a(new byte[]{114, -6, 48}, new byte[]{7, -120, 92, -29, -4, -10, -3, -64}), str3);
            } catch (Throwable unused) {
            }
        }
        return map;
    }

    public static JSONObject parse(LinkedHashMap<String, String> linkedHashMap, String str) {
        JSONObject jSONObjectC;
        try {
            char c = 7;
            SpiderDebug.log(C0098a.a(new byte[]{-57, -45, 103, 61, 95, -30, -4, 115, -27, -100, 86, 56, 13, -37, -22, 60, -55, -35, 117, 48, 28, -122, -95, 50}, new byte[]{-117, -68, 6, 89, 127, -88, -113, 28}));
            if (linkedHashMap.size() > 0) {
                for (String str2 : linkedHashMap.keySet()) {
                    HashMap<String, String> reqHeader = getReqHeader(linkedHashMap.get(str2));
                    try {
                        byte[] bArr = new byte[8];
                        bArr[0] = -12;
                        bArr[1] = 49;
                        bArr[2] = 112;
                        bArr[3] = 59;
                        bArr[4] = 91;
                        bArr[5] = -78;
                        bArr[6] = 122;
                        bArr[c] = 120;
                        String str3 = reqHeader.get(C0098a.a(new byte[]{-127, 67, 28}, bArr));
                        byte[] bArr2 = {47, 11, 80};
                        byte[] bArr3 = new byte[8];
                        bArr3[0] = 90;
                        bArr3[1] = 121;
                        try {
                            bArr3[2] = 60;
                            bArr3[3] = -128;
                            bArr3[4] = 122;
                            bArr3[5] = 110;
                            bArr3[6] = 109;
                            bArr3[7] = -10;
                            reqHeader.remove(C0098a.a(bArr2, bArr3));
                            SpiderDebug.log(str3 + str);
                            jSONObjectC = C0214g.c(str, f.f(str3 + str, reqHeader));
                        } catch (Throwable th) {
                            th = th;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                    }
                    if (jSONObjectC == null) {
                        c = 7;
                    } else {
                        byte[] bArr4 = new byte[6];
                        bArr4[0] = 14;
                        bArr4[1] = 45;
                        bArr4[2] = 71;
                        try {
                            bArr4[3] = 11;
                            bArr4[4] = -8;
                            bArr4[5] = 5;
                            byte[] bArr5 = new byte[8];
                            bArr5[0] = 100;
                            bArr5[1] = 85;
                            bArr5[2] = 1;
                            bArr5[3] = 121;
                            bArr5[4] = -105;
                            bArr5[5] = 104;
                            bArr5[6] = 46;
                            try {
                                bArr5[7] = 115;
                                jSONObjectC.put(C0098a.a(bArr4, bArr5), str2);
                                SpiderDebug.log(jSONObjectC.toString());
                                return jSONObjectC;
                            } catch (Throwable th3) {
                                th = th3;
                                SpiderDebug.log(th);
                                c = 7;
                            }
                        } catch (Throwable th4) {
                            th = th4;
                            SpiderDebug.log(th);
                            c = 7;
                        }
                    }
                }
            }
        } catch (Throwable th5) {
            SpiderDebug.log(th5);
        }
        return new JSONObject();
    }
}
