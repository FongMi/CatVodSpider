package com.github.catvod.parser;

import android.util.Base64;
import com.github.catvod.crawler.SpiderDebug;
import com.github.catvod.spider.merge.a.C0098a;
import com.github.catvod.spider.merge.oZP;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /tmp/decompiler/446907477a41490d9e71cfdd71d695e7/classes.dex */
public class MixWeb {
    public static HashMap<String, ArrayList<String>> a = new HashMap<>();
    static HashMap<String, ArrayList<String>> b = null;

    public static Object[] loadHtml(String str, String str2) {
        try {
            String str3 = new String(Base64.decode(str2, 10), StandardCharsets.UTF_8);
            String strD = oZP.d("7F5356250336011607244C3D01021B7F66691D1B1A2D525F49071220086B7F530328183910519FE6CFB3EBFF4B6E183C0103127F6669180A03204C3D011B076C09240006017C4E161A0103240221583B0E310977550C182F18301B1B4A6318300D1B58291838195457220434071C1235512001095A794E755A517D7D0130010E5729182105421230193C0352551941003442342E0125141B1E230030574F142E02211001037C4E1C3052322C1939141B12082964454D576E525F490212350D751B0E1A245177070A19250927101D55610F3A1B1B122F186857181223073C01131E2441361A02073D0530581C0320023157517D7D0130010E572F0D38105255370530021F18331877550C182F18301B1B4A631B3C111B1F7C08300306142441221C0B03294E6B7F535829093411517D7D0E3A1116494B5026161D1E31186B7F1916334C34050636331E340C522C62062D064C2A7A6623141D57341E39251C4A634F2007035463575F030E05610533070E1A24242118034A634E6E7F0918334423141D572851654E064B201C3C341D0520157B190A1926183D4E065C6A452E7F1916334C0027234A201C3C341D0520150E1C325C341E39251C4C4B0533070E1A24242118034A280A271402120918381944557D0533070E1A244C2614011323032D4848162D003A024204221E3C051B04610D391900006C1F34180A5A2E1E3C120619610D391900006C0A3A070204664C33070E1A240E3A070B123351724548572000391A1811340039060C0524093B484803331930524F00240E3E1C1B162D003A0209022D0026161D12240268521B053409725502183B0D39190000271939191C143309301B5250351E20104857321E36484D5C143E195E4D497D433C131D162C096B57547D3C66311A0C022C093B01410033052110471E271E34180A3F3501395C547D7D4326161D1E31186B7F53582303310C517D7D433D01021B7F");
            StringBuilder sb = new StringBuilder();
            if (a.containsKey(str)) {
                ArrayList<String> arrayList = a.get(str);
                for (int i = 0; i < arrayList.size(); i++) {
                    sb.append(C0098a.a(new byte[]{102}, new byte[]{68, 76, -5, 96, -92, -93, -51, -41}));
                    sb.append(arrayList.get(i));
                    sb.append(C0098a.a(new byte[]{66}, new byte[]{96, 102, -103, 35, -101, -124, 69, -64}));
                    if (i < arrayList.size() - 1) {
                        sb.append(C0098a.a(new byte[]{-82}, new byte[]{-126, 51, 45, 124, -70, 115, 85, -44}));
                    }
                }
            }
            return new Object[]{200, C0098a.a(new byte[]{-105, 109, 100, 60, 18, -100, 25, -39, -113, 51, 60, 43, 85, -107, 31, -57, -122, 124, 33, 106, 104, -96, 43, -103, -37, 42}, new byte[]{-29, 8, 28, 72, 61, -12, 109, -76}), new ByteArrayInputStream(strD.replace(C0098a.a(new byte[]{3, -49, -69, 97, 115}, new byte[]{32, -70, -55, 13, 80, -53, 61, 115}), str3).replace(C0098a.a(new byte[]{-95, -63, -79, 0, 43}, new byte[]{-126, -85, -55, 115, 8, 118, 22, 60}), sb.toString()).getBytes(StandardCharsets.UTF_8))};
        } catch (Throwable th) {
            th.printStackTrace();
            return null;
        }
    }

    public static JSONObject parse(LinkedHashMap<String, HashMap<String, String>> linkedHashMap, String str, String str2, String str3) {
        try {
            byte b2 = -32;
            byte b3 = -123;
            byte b4 = 25;
            if (b == null) {
                b = new HashMap<>();
                for (String str4 : linkedHashMap.keySet()) {
                    HashMap<String, String> map = linkedHashMap.get(str4);
                    if (map.get(C0098a.a(new byte[]{92, -52, b4, b3}, new byte[]{40, -75, 105, b2, -58, -74, -16, -74})).equals(C0098a.a(new byte[]{-11}, new byte[]{-59, b2, 94, -16, 15, -90, -38, -102}))) {
                        try {
                            JSONArray jSONArray = new JSONObject(map.get(C0098a.a(new byte[]{-97, -13, 108}, new byte[]{-6, -117, 24, 7, -50, 0, 46, 37}))).getJSONArray(C0098a.a(new byte[]{-102, -19, -67, -90}, new byte[]{-4, -127, -36, -63, 116, 39, -8, 63}));
                            for (int i = 0; i < jSONArray.length(); i++) {
                                String string = jSONArray.getString(i);
                                ArrayList<String> arrayList = b.get(string);
                                if (arrayList == null) {
                                    arrayList = new ArrayList<>();
                                    b.put(string, arrayList);
                                }
                                arrayList.add(str4);
                            }
                        } catch (Throwable unused) {
                        }
                    }
                    b2 = -32;
                    b3 = -123;
                    b4 = 25;
                }
            }
            ArrayList<String> arrayList2 = new ArrayList<>();
            ArrayList<String> arrayList3 = b.get(str2);
            byte b5 = 73;
            byte b6 = -12;
            if (arrayList3 == null || arrayList3.isEmpty()) {
                Iterator<String> it = linkedHashMap.keySet().iterator();
                while (it.hasNext()) {
                    HashMap<String, String> map2 = linkedHashMap.get(it.next());
                    if (map2.get(C0098a.a(new byte[]{72, -65, -86, -32}, new byte[]{60, -58, -38, -123, 73, -69, -96, 5})).equals(C0098a.a(new byte[]{-11}, new byte[]{-59, 114, 19, -2, -39, 112, -24, -108}))) {
                        arrayList2.add(map2.get(C0098a.a(new byte[]{106, -93, 70}, new byte[]{31, -47, 42, 25, -61, 18, 50, -118})));
                    }
                }
            } else {
                int i2 = 0;
                while (i2 < arrayList3.size()) {
                    HashMap<String, String> map3 = linkedHashMap.get(arrayList3.get(i2));
                    if (map3.get(C0098a.a(new byte[]{-1, b5, -29, -111}, new byte[]{-117, 48, -109, b6, -113, 121, -78, 65})).equals(C0098a.a(new byte[]{-94}, new byte[]{-110, 89, -90, 75, -77, -93, 49, -123}))) {
                        arrayList2.add(map3.get(C0098a.a(new byte[]{41, -44, 31}, new byte[]{92, -90, 115, 127, 32, -46, 88, 1})));
                    }
                    i2++;
                    b5 = 73;
                    b6 = -12;
                }
            }
            if (!arrayList2.isEmpty()) {
                a.put(str2, arrayList2);
            }
            if (!arrayList2.isEmpty()) {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put(C0098a.a(new byte[]{-104, -55, -104}, new byte[]{-19, -69, -12, 0, -84, 34, 7, 70}), C0098a.a(new byte[]{-33, -117, -33, -29, 31, -102, 100, -94, -53, -106, -115, -42, 15, -40, 28, -24, -51, -33, -42, -9, 7, -57, 118}, new byte[]{-81, -7, -80, -101, 102, -96, 75, -115}) + str2 + C0098a.a(new byte[]{-13, -5, 106, -23, 61}, new byte[]{-43, -114, 24, -123, 0, 33, 81, -56}) + Base64.encodeToString(str3.getBytes(), 10));
                jSONObject.put(C0098a.a(new byte[]{-78, 58, 108, 99, 75}, new byte[]{-62, 91, 30, 16, 46, 93, 50, 23}), 1);
                jSONObject.put(C0098a.a(new byte[]{84, 84}, new byte[]{33, 53, 51, -85, 25, 9, -54, 75}), C0098a.a(new byte[]{50, 123, -70, -10, 101, -12, 7, 99, 74, 58, -16, -65, 33, -49, 15, 34, 27, 123, -73, -20, 41, -42, 50, 108, 78, 36, -18, -81, 50, -72, 49, 37, 17, 34, -12, -92, 41, -32, 80, 120, 86, 52, -127, -17, 121, -12, 3, 27, 26, 118, -117, -10, 125, -73, 83, 127, 72, 58, -13, -87, 41, -80, 45, 4, 43, 89, -116, -77, 41, -12, 15, 39, 26, 52, -121, -6, 106, -13, 9, 101, 95, 87, -88, -19, 102, -11, 3, 99, 70, 32, -18, -81, 39, -84, 80, 124, 73, 58, -11, -85, 41, -53, 7, 42, 30, 102, -87, -80, 60, -85, 81, 98, 76, 34}, new byte[]{127, 20, -64, -97, 9, -104, 102, 76}));
                return jSONObject;
            }
        } catch (Throwable th) {
            SpiderDebug.log(th);
        }
        return new JSONObject();
    }
}
